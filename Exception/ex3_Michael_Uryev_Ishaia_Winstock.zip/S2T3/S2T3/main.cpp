//- - - - - - - - -include section - - - - - - - - -
#include "Calculator.h"

//- - - - - - - - - - - - - - - - - - - - - - - - - - - -
int main()
{
	 Calculator calculator;
	calculator.run();
	return 0;
}
