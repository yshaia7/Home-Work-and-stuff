#pragma once
#include "BaseValidator.h"

template<class A, class B>
class ComplexValidator : public BaseValidator<class T>
{
public:
	ComplexValidator() {};
	~ComplexValidator() {};
};